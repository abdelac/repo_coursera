.when("/signup", {
  templateUrl: "signup.html",
  controller: "SignUpController as signUpCtrl"
})
